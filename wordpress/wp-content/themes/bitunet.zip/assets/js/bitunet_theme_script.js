var Bitunet_Child_Theme_JS;

(function($) {
    'use strict';

    Bitunet_Child_Theme_JS = {
        init: function() {
        },
    };

    Bitunet_Child_Theme_JS.init();

}(jQuery));