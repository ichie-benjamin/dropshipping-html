# Changelog

## 1.1.3
- ADD: 'Search Results' condition for Archives

## 1.1.2
- FIX: Magic Button modal loader
- FIX: Page settings import on template import

## 1.1.1
- UPD: Make Post Types Archive: Post condition more clear to use

## 1.1.0
- ADD: archive and single structures
- ADD: Archive Taxonomy condition
- UPD: Archive Post Type condition
- FIX: Theme template source

## 1.0.7

- ADD: new setting - Prevent Pro locations registration (avoid conflicts with themes without Elementor Pro support)
- FIX: prevent errors when Elementor is not installed
- FIX: Elementor 2.1.0 compatibility
- FIX: avoid of duplicating Active conditions

## 1.0.6

- ADD: allow to install JetPluginsWizard from dashboard
