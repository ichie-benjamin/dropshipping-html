# Jet Popup For Elementor

Build popup with any layout in drag&drop way, change its position and trigger event in few clicks.

# ChangeLog

## [1.0.0](https://github.com/ZemezLab/jet-popup/releases/tag/1.0.0)

* Init
