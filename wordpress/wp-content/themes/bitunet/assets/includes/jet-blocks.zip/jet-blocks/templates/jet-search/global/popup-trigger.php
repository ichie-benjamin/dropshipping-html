<?php
/**
 * Popup trigger
 */
?>
<div class="jet-search__popup-trigger-container">
	<button type="button" class="jet-search__popup-trigger"><?php
		$this->__html( 'search_popup_trigger_icon', '<i class="jet-search__popup-trigger-icon %s"></i>' )
	?></button>
</div>