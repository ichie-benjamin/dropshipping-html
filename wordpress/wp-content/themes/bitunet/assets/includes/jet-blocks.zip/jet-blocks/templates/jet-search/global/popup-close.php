<?php
/**
 * Popup trigger
 */

$this->__html( 'search_close_icon', '<button type="button" class="jet-search__popup-close"><i class="jet-search__popup-close-icon %s"></i></button>' );
